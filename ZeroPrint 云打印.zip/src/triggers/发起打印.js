const axios = require('axios');
const crypto = require("crypto");

// ===== 错误消息常量 =====
const ERRORS = {
    // 校验错误
    MISSING_TARGET: '缺少必填参数: 打印机 ID',
    MISSING_FILES: '缺少必填参数: 文件',
    INVALID_TARGET: '打印机 ID 无效',
    INVALID_FILE_URLS: '未解析到有效的文件地址，请检查文件来源（智能助手输出/附件上传/文本框输入）',

    // 请求结果
    REQUEST_SUCCESS: '请求成功',
    PRINT_SUBMITTED: '已提交至打印机',
    ALL_REQUESTS_FAILED: '全部请求失败',
    PARTIAL_REQUESTS_FAILED: '部分请求失败',

    // 后端错误码对应的消息
    INTERNAL_ERROR: 'ZeroPrint 服务器内部错误',
};

// ===== 参数提取 =====
const { apiEndpoint, publicKey } = agentConf;
const { target, files, copies, pageSize, duplex, color, orientation, resolution, id, callbackUrl } = triggerConf;

// ===== 必填参数校验 =====
if (!target?.trim()) throw new Error(ERRORS.MISSING_TARGET);
if (!files?.trim()) throw new Error(ERRORS.MISSING_FILES);

// ===== target 格式校验 =====
if (!/^[a-f0-9]{64}$/.test(target)) throw new Error(ERRORS.INVALID_TARGET);

// ===== 解析 files =====
const fileUrls = parseFiles();
if (!fileUrls.length) throw new Error(ERRORS.INVALID_FILE_URLS);

// ===== 构建通用打印参数 =====
const commonPrintParams = {
    ...(copies && { copies }),
    ...(pageSize && { pageSize }),
    ...(duplex && { duplex }),
    ...(color && { color }),
    ...(orientation && { orientation }),
    ...(resolution && { resolution }),
    ...(id && callbackUrl && { id, callbackUrl }),
};

// ===== 批量发送并汇总结果 =====
const settledResults = await Promise.allSettled(fileUrls.map(sendPrintRequest));

const failedRequests = settledResults.reduce((accumulator, result, index) => {
    if (result.status === 'rejected') {
        const url = fileUrls[index];
        const errorMessage = translateError(result.reason);
        accumulator.push(`${url} : ${errorMessage}`);
    }
    return accumulator;
}, []);

if (!failedRequests.length) {
    return {
        result: ERRORS.REQUEST_SUCCESS,
        detail: ERRORS.PRINT_SUBMITTED
    };
}

const isAllFailed = failedRequests.length === fileUrls.length;
return {
    result: isAllFailed ? ERRORS.ALL_REQUESTS_FAILED : ERRORS.PARTIAL_REQUESTS_FAILED,
    detail: failedRequests.join('; ')
};

// ============================================================================
// 辅助函数
// ============================================================================

function parseFiles() {
    const trimmed = files.trim();
    if (trimmed.startsWith('[')) return JSON.parse(trimmed).map(item => item.url.trim());
    if (trimmed.startsWith('http')) return trimmed.split(',').map(url => url.trim()).filter(Boolean);
    throw new Error(ERRORS.INVALID_FILE_URLS);
}

function encryptData(plaintext) {
    const wrappedKey = publicKey.match(/.{1,64}/g).join('\n');
    const pemKey = `-----BEGIN PUBLIC KEY-----\n${wrappedKey}\n-----END PUBLIC KEY-----`;
    const aesKey = crypto.randomBytes(32);
    const nonce = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, nonce);
    const encryptedData = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const authTag = cipher.getAuthTag();
    const encryptedAesKey = crypto.publicEncrypt(
        { key: pemKey, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha256' },
        aesKey
    );
    return Buffer.concat([encryptedAesKey, nonce, encryptedData, authTag]).toString('base64');
}

function sendPrintRequest(fileUrl) {
    const printData = JSON.stringify({ url: fileUrl, ...commonPrintParams });
    const encryptedPayload = encryptData(printData);
    return axios.post(`${apiEndpoint}/api/print`, { target, data: encryptedPayload }, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 10000,
    });
}

function translateError(error) {
    if (error.response?.data?.code === 'INTERNAL_ERROR') {
        return ERRORS.INTERNAL_ERROR;
    }
    return error.response?.data?.message || error.message;
}